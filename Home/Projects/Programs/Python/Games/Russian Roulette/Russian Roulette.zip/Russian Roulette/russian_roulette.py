import os
import sys
import ctypes

def is_admin():
    """Controlla se il programma è in esecuzione con privilegi di amministratore."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin(script_path):
    """Riavvia il programma con privilegi di amministratore."""
    if not is_admin():
        # Costruisci il comando per riavviare il programma come amministratore
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, script_path, None, 1)
        sys.exit()

# Specifica il percorso del file Python da eseguire
script_to_run = "game.py"  # Modifica questo percorso

# Controlla se il programma è in esecuzione come amministratore
run_as_admin(script_to_run)

# Esegui il file Python specificato
os.system(f'python "{script_to_run}"')