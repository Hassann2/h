import numpy as np
import matplotlib.pyplot as plt
from tkinter import Tk, Label, Entry, Button, messagebox, Toplevel, Text, Scrollbar

# Function to calculate and draw the parabola
def draw_parabola():
    try:
        a = float(entry_a.get())
        b = float(entry_b.get())
        c = float(entry_c.get())
        
        # Create an array of x values
        x = np.linspace(-10, 10, 400)
        y = a * x**2 + b * x + c
        
        # Show the steps in a new window
        show_steps(a, b, c)

        # Create the graph
        plt.figure(figsize=(10, 6))
        plt.plot(x, y, label=f'y = {a}x² + {b}x + {c}', color='blue')
        plt.title('Graph of the Parabola', fontsize=14)
        plt.xlabel('x', fontsize=12)
        plt.ylabel('y', fontsize=12)
        plt.axhline(0, color='black', linewidth=0.5, ls='--')
        plt.axvline(0, color='black', linewidth=0.5, ls='--')
        plt.grid(color='gray', linestyle='--', linewidth=0.5)
        plt.legend()
        plt.xlim(-10, 10)
        plt.ylim(-10, 10)
        plt.show()
        
    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numeric values.")

# Function to show the steps in a new window
def show_steps(a, b, c):
    steps_window = Toplevel(root)
    steps_window.title("Steps to Calculate the Parabola")
    steps_window.configure(bg='#f0f0f0')

    # Create a Text widget to show the steps
    text = Text(steps_window, wrap='word', bg='#ffffff', font=('Arial', 12), width=50, height=15)
    text.pack(padx=10, pady=10)

    # Add a scrollbar
    scrollbar = Scrollbar(steps_window, command=text.yview)
    scrollbar.pack(side='right', fill='y')
    text.config(yscrollcommand=scrollbar.set)

    # Detailed steps
    steps = (
        "Steps to calculate the function of the parabola:\n\n"
        "1. Identify the coefficients of the parabola:\n"
        f"   - Coefficient a: {a}\n"
        f"   - Coefficient b: {b}\n"
        f"   - Coefficient c: {c}\n\n"
        "2. The general form of the parabola is: y = ax² + bx + c\n\n"
        "3. Choose a range of values for x. In this case, we chose from -10 to 10.\n\n"
        "4. Calculate the values of y for each value of x using the formula:\n"
        "   - y = a * x² + b * x + c\n\n"
        "5. Draw the graph of the parabola using the calculated values.\n\n"
        "6. The graph shows the shape of the parabola based on the provided coefficients.\n"
    )

    text.insert('1.0', steps)
    text.config(state='disabled')  # Disable text editing

# Create the main window
root = Tk()
root.title("Parabola Calculator")
root.configure(bg='#f0f0f0')  # Background color

# Configure the grid for responsiveness
root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=1)
root.grid_rowconfigure(2, weight=1)
root.grid_rowconfigure(3, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)

# Create input fields with styles
Label(root, text="Coefficient a:", bg='#f0f0f0', font=('Arial', 12)).grid(row=0, column=0, padx=10, pady=10, sticky='ew')
entry_a = Entry(root, font=('Arial', 12))
entry_a.grid(row=0, column=1, padx=10, pady=10, sticky='ew')

Label(root, text="Coefficient b:", bg='#f0f0f0', font=('Arial', 12)).grid(row=1, column=0, padx=10, pady=10, sticky='ew')
entry_b = Entry(root, font=('Arial', 12))
entry_b.grid(row=1, column=1, padx=10, pady=10, sticky='ew')

Label(root, text="Coefficient c:", bg='#f0f0f0', font=('Arial', 12)).grid(row=2, column=0, padx=10, pady=10, sticky='ew')
entry_c = Entry(root, font=('Arial', 12))
entry_c.grid(row=2, column=1, padx=10, pady=10, sticky='ew')

# Create the button to draw the parabola
button = Button(root, text="Draw Parabola", command=draw_parabola, bg='#4CAF50', fg='white', font=('Arial', 12))
button.grid(row=3, columnspan=2, pady=20, sticky='ew')

# Start the GUI
root.mainloop()